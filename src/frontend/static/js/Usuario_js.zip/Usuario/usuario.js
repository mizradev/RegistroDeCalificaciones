(()=>{
    alert("Hola Mundo")

})();